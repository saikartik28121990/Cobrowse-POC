
import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
  AfterViewInit
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import CobrowseIO from 'cobrowse-sdk-js';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {

  @Output() logout = new EventEmitter<void>();

  /** Initialize canvas when it appears under *ngIf */
  @ViewChild('signatureCanvas') set signatureCanvasSetter(canvasEl: ElementRef<HTMLCanvasElement> | undefined) {
    if (canvasEl) {
      this.canvas = canvasEl;
      this.setupCanvas();
    }
  }

  private canvas?: ElementRef<HTMLCanvasElement>;
  private ctx: CanvasRenderingContext2D | null = null;

  private drawing = false;
  private lastX = 0;
  private lastY = 0;

  activeTab: 'pending' | 'completed' = 'pending';
  selectedTask: string | null = null;
  actionValue = '';

  showCobrowse = false;
  cobrowseCode = '';

  completedTaskDetails: {
    title: string;
    description: string;
    completedOn: string;
    referenceId: string;
  } | null = null;

  loggedInUser = {
    username: 'John Doe',
    tasks: [
      { name: 'Basic details', completed: true },
      { name: 'Address details', completed: true },
      { name: 'Employment details', completed: true },
      { name: 'VISA details', completed: false },
      { name: 'Application details', completed: false },
      { name: 'Document upload', completed: false },
      { name: 'Document signing', completed: false }
    ]
  };

  taskLabels: Record<string, string> = {
    'VISA details': 'Enter VISA details',
    'Application details': 'Enter application details',
    'Document upload': 'Upload document',
    'Document signing': 'Sign document'
  };

  ngOnInit() {

    console.log("init")
    CobrowseIO.api = 'https://dev.bluemena.com';
    CobrowseIO.license = 'IrXHA98IC4P3JQ';

    CobrowseIO.client().then(() => {
      CobrowseIO.start();
      CobrowseIO.createSessionCode().then((code: string) => {
        console.log(code)
        this.cobrowseCode = code;
      });
    });
  }

  ngAfterViewInit() {
    // Canvas setup happens in the ViewChild setter when the element is rendered.
  }

  /** Canvas setup with devicePixelRatio scaling and black stroke */
  private setupCanvas() {
    if (!this.canvas) return;

    const canvasEl = this.canvas.nativeElement;
    const cssWidth = 600;
    const cssHeight = 200;
    const dpr = window.devicePixelRatio || 1;

    // Set internal buffer size for crisp lines on high-DPI
    canvasEl.width = Math.floor(cssWidth * dpr);
    canvasEl.height = Math.floor(cssHeight * dpr);

    // Keep CSS size as intended
    canvasEl.style.width = cssWidth + 'px';
    canvasEl.style.height = cssHeight + 'px';

    this.ctx = canvasEl.getContext('2d');
    if (this.ctx) {
      // Scale so drawing uses CSS pixels
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.ctx.lineWidth = 2;
      this.ctx.lineCap = 'round';
      this.ctx.strokeStyle = 'black'; // black stroke
    }
  }

  // ---- Pointer Events (mouse/touch/pen) ----
  onPointerDown(event: PointerEvent) {
    if (!this.ctx || !this.canvas) return;
    this.drawing = true;
    const { x, y } = this.getEventPos(event);
    this.lastX = x;
    this.lastY = y;
    (event.target as Element).setPointerCapture?.(event.pointerId);
    event.preventDefault();
  }

  onPointerMove(event: PointerEvent) {
    if (!this.drawing || !this.ctx) return;
    const { x, y } = this.getEventPos(event);
    this.ctx.beginPath();
    this.ctx.moveTo(this.lastX, this.lastY);
    this.ctx.lineTo(x, y);
    this.ctx.stroke();
    this.lastX = x;
    this.lastY = y;
    event.preventDefault();
  }

  onPointerUp(event: PointerEvent) {
    this.drawing = false;
    event.preventDefault();
  }

  private getEventPos(event: PointerEvent) {
    const rect = this.canvas!.nativeElement.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
  }

  get pendingTasks() {
    return this.loggedInUser.tasks.filter(t => !t.completed);
  }

  get completedTasks() {
    return this.loggedInUser.tasks.filter(t => t.completed);
  }

  get isSignatureTask() {
    return this.selectedTask === 'Document signing';
  }

  get currentLabel() {
    return this.selectedTask ? this.taskLabels[this.selectedTask] : '';
  }

  handleCardClick(taskName: string) {
    const task = this.loggedInUser.tasks.find(t => t.name === taskName);
    if (!task) return;

    if (task.completed) {
      // Show static details for completed task (dummy values for now)
      this.completedTaskDetails = {
        title: taskName,
        description: 'This task was completed successfully.',
        completedOn: '12 Jan 2026',
        referenceId: 'REF-12345'
      };
      this.selectedTask = null; // ensure form is hidden
      return;
    }

    // Pending task → open form
    this.completedTaskDetails = null;
    this.selectedTask = taskName;
    this.actionValue = '';
  }

  handleSubmit() {
    // Mark task as completed (works for both regular and signature tasks)
    const task = this.loggedInUser.tasks.find(t => t.name === this.selectedTask);
    if (task) task.completed = true;

    // Optionally, you could store a timestamp here for real "Completed On"
    // e.g., task.completedOn = new Date().toISOString();

    this.selectedTask = null;
    this.activeTab = 'completed';
  }
}
