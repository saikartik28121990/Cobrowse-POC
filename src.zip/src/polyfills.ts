/**
 * This file includes polyfills needed by Angular and is loaded before the app.
 * You can add your own extra polyfills to this file.
 */

/***************************************************************************************************
 * BROWSER POLYFILLS
 */

// Polyfill for IE11 (if you need older browsers)
// import 'core-js/es';
// import 'zone.js'; // Included with Angular CLI by default

/***************************************************************************************************
 * Zone JS is required by default for Angular itself.
 */
