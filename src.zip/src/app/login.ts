import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html'
})
export class LoginComponent {
  @Output() loginSuccess = new EventEmitter<void>();

  email = '';
  password = '';
  message = '';

  async handleSubmit() {
    try {
      const response = await fetch('http://localhost:5001/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: this.email, password: this.password })
      });

      const data = await response.json();

      if (data.success) {
        localStorage.setItem('user', JSON.stringify(data.user));
        this.loginSuccess.emit();
      } else {
        this.message = 'Invalid email or password';
      }
    } catch (err) {
      console.error(err);
      this.message = 'Server error. Please try again.';
    }
  }
}
