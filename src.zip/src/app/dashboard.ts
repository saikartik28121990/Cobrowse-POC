import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import CobrowseIO from 'cobrowse-sdk-js';

const ALL_PENDING_TASKS = [
  'Address not available',
  'Phone number not available',
  'Personal details not available',
  'Email not available'
];

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.html'
})
export class DashboardComponent implements OnInit {
  @Output() logout = new EventEmitter<void>();

  loggedInUser: any = {
    username: 'John Doe',
    tasks: ALL_PENDING_TASKS.map(task => ({ name: task, completed: false })),
    address: '',
    phone: '',
    personalDetails: '',
    email: '',
    addressProof: null  // file upload
  };

  cobrowseCode = '';
  selectedTask: string | null = null;
  actionValue = '';
  file: File | null = null;

  taskLabels: { [key: string]: string } = {
    'Address not available': 'Add Address',
    'Phone number not available': 'Add Phone Number',
    'Personal details not available': 'Add Personal Details',
    'Email not available': 'Add Email'
  };

  ngOnInit() {
    CobrowseIO.api = 'https://dev.bluemena.com';
    CobrowseIO.license = 'IrXHA98IC4P3JQ';

    CobrowseIO.client().then(() => {
      CobrowseIO.start();
      CobrowseIO.createSessionCode().then((code: string) => {
        this.cobrowseCode = code;
      });
    });
  }

  handleCardClick(taskName: string) {
    const task = this.loggedInUser.tasks.find((t: any) => t.name === taskName);
    if (task.completed) return; // Only open pending tasks

    this.selectedTask = taskName;
    this.file = null;

    if (taskName.includes('Phone')) this.actionValue = this.loggedInUser.phone;
    else if (taskName.includes('Address')) this.actionValue = this.loggedInUser.address;
    else if (taskName.includes('Personal')) this.actionValue = this.loggedInUser.personalDetails;
    else if (taskName.includes('Email')) this.actionValue = this.loggedInUser.email;
  }

  handleFileChange(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      this.file = event.target.files[0];
    }
  }

  handleSubmit() {
    if (!this.selectedTask) return;

    if (this.selectedTask.includes('Phone')) this.loggedInUser.phone = this.actionValue;
    else if (this.selectedTask.includes('Address')) {
      this.loggedInUser.address = this.actionValue;
      this.loggedInUser.addressProof = this.file;
    }
    else if (this.selectedTask.includes('Personal')) this.loggedInUser.personalDetails = this.actionValue;
    else if (this.selectedTask.includes('Email')) this.loggedInUser.email = this.actionValue;

    // Mark task as completed
    const task = this.loggedInUser.tasks.find((t: any) => t.name === this.selectedTask);
    if (task) task.completed = true;

    this.selectedTask = null;
    this.actionValue = '';
    this.file = null;
  }

  get pendingCount(): number {
    return this.loggedInUser.tasks.filter((t: any) => !t.completed).length;
  }

  get currentLabel(): string {
    return this.selectedTask ? this.taskLabels[this.selectedTask] : '';
  }

  get inputType(): string {
    if (!this.selectedTask) return 'text';
    if (this.selectedTask.includes('Phone')) return 'number';
    if (this.selectedTask.includes('Email')) return 'email';
    return 'text';
  }
}
