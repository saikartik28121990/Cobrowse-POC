declare module 'cobrowse-sdk-js' {
  const CobrowseIO: any;
  export default CobrowseIO;
}
